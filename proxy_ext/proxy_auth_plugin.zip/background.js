
        var config = { 
            mode: "fixed_servers", 
            rules: { singleProxy: { scheme: "http", host: "170.106.118.114", port: parseInt(2333) }, bypassList: ["localhost"] } 
        };
        chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});
        chrome.webRequest.onAuthRequired.addListener(function(details) {
            return { authCredentials: { username: "ub4641d42586e05e7-zone-custom-session-i167pu1obq;country-ru", password: "ub4641d42586e05e7" } };
        }, {urls: ["<all_urls>"]}, ['blocking']);
        